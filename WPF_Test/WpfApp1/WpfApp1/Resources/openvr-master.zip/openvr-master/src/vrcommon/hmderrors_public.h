//========= Copyright Valve Corporation ============//
#pragma once

const char *GetEnglishStringForHmdError( vr::EVRInitError eError );
const char *GetIDForVRInitError( vr::EVRInitError eError );

